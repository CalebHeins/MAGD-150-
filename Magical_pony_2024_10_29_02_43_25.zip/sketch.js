function setup() {
  createCanvas(400, 400);
}

function draw() {
let img1, img2, transparentImg;

function preload() {
  img1 = loadImage("C:\Users\caleb\Downloads\OIP.jpg");
  img2 = loadImage("C:\Users\caleb\Downloads\OIP (1).jpg");
 function draw() {
  background(220);
  image(img1, mouseX, mouseY, 100, 100); 
  image(img2, 50, 50, 100, 100); 
   function draw() {
  background(220);
  image(img1, mouseX, mouseY, 100, 100);
  image(img2, 50, 50, 100, 100);
  image(transparentImg, mouseX, mouseY, 100, 100);
  
  textSize(32);
  fill(255, 0, 0);
  stroke(0);
  text('Hi my name is caleb', 10, 30, 200, 100); 
}

  
}

}
}