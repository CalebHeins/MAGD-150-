let myArray = [10, 20, 30, 40, 50];

function setup() {
  createCanvas(400, 400);
  for (let i = 0; i < myArray.length; i++) {
    myArray[i] = i * 10;
    print("Length of myArray: " + myArray.length); 
  }
}

function draw() {
  background(220);
  for (let i = 0; i < myArray.length; i++) {
    ellipse(myArray[i], height / 2, 20, 20);
    myArray[i] += 1;
    if (myArray[i] > width) {
      myArray[i] = 0;
    }
  }
}

function mousePressed() {
  myArray[0] = mouseX; 
}
