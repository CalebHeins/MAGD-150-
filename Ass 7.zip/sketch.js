function setup() {
  createCanvas(400, 400);
  angleMode(DEGREES);
  noLoop(); 
}

function draw() {
  background(220);
  for (let i = 0; i < 5; i++) {
    push(); // Save the current state
    translate(i * 80 + 30, height / 2); 
    let scaleValue = 1 + i * 0.5; 
    scale(scaleValue); 
    rotate(i * 30); 
    drawShape();
    pop(); 
  }
}

function drawShape() {
  fill(100, 150, 203);
  stroke(0);
  rect(-25, -25, 51, 50); 
}

function computeValue() {
  let value = random(1, 100); 
  print(value); 
  return value; 
}


